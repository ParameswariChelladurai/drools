package com.javainuse.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Product;
import com.javainuse.service.JewelleryShopService;

@RestController
public class JewelleryShopController {

	private final JewelleryShopService jewelleryShopService;

	@Autowired
	public JewelleryShopController(JewelleryShopService jewelleryShopService) {
		this.jewelleryShopService = jewelleryShopService;
	}

	@RequestMapping(value = "/getDiscount", method = RequestMethod.GET, produces = "application/json")
	public Product getQuestions(@RequestParam(required = true) String type) {

		Product product = new Product();
		product.setType(type);

		jewelleryShopService.getProductDiscount(product);

		return product;
	}
	@RequestMapping(value = "/orderProduct/{id}", method = RequestMethod.GET, produces = "application/json")
	public Product saveProduct(@PathVariable  ("id") Long id) {

		Product productOrders = new Product();
		//product.setType(type);
		productOrders=	 jewelleryShopService.saveProduct(id);
		System.out.println(" Type " + productOrders.getType() + " Discount : " + productOrders.getDiscount());
	
	//	jewelleryShopService.getProductDiscount(product);

		return productOrders;
	}
	

	@RequestMapping(value = "/findProduct/{type}", method = RequestMethod.GET, produces = "application/json")
	public Product findProduct(@PathVariable  ("type") String type) {

		Product product = new Product();
		//product.setType(type);
		product=	 jewelleryShopService.findProductByType(type);
		System.out.println(" @Type " + product.getType() + " @Discount : " + product.getDiscount());
		
		
		jewelleryShopService.getProductDiscount(product);
		
		System.out.println(" @@@Type " + product.getType() + " @@@Discount : " + product.getDiscount());
		
		return product;
	}

}
