package com.javainuse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.google.common.base.Optional;
import com.javainuse.model.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

	
	
	@Query("select p from Product p where p.type = :type")
    public Product findProductByType(@Param("type")String type);
	
	/*@Query("SELECT t FROM Todo t where t.title = :title AND t.description = :description")
    public Optional<Todo> findByTitleAndDescription(@Param("title") String title, 
                                                    @Param("description") String description);*/

}
